
import usb_generic

d = usb_generic.Device("/dev/serial0")
d.start()
